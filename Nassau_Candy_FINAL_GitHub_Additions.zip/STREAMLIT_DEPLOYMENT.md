# Streamlit Deployment

## Entry point
`app/app.py`

## Local run
From the repository root:

```bash
streamlit run app/app.py
```

## Streamlit Community Cloud
1. Open https://share.streamlit.io
2. Connect the GitHub account that owns the repository.
3. Create a new app.
4. Select repository `krishna757095-jpg/nassau-candy-factory-reallocation-ml`.
5. Branch: `main`
6. Main file path: `app/app.py`
7. Deploy.

The deployment uses the existing project artifacts under `data/`, `models/`, and `results/`.
